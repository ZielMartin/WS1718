public class HelloService extends Service {
	private Looper mServiceLooper;
	private ServiceHandler mServiceHandler;

	// Handler, der die Messages vom Thread bekommt
	private final class ServiceHandler extends Handler {
		public ServiceHandler(Looper looper) {
			super(looper);
		}
		@Override
		public void handleMessage(Message msg) {
			// Messages behandeln, fürs Beispiel 5 Sekunden warten.
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// Interrupt status wiederherstellen.
				Thread.currentThread().interrupt();
			}
			// Service mit der startId stoppen, damit nicht während der Behandlung
			// eines anderen Jobs gestoppt wird
			stopSelf(msg.arg1);
		}
	}

	@Override
	public void onCreate() {
		// Thread für Service starten
		// Damit wird Service vom Main Thread des Prozesses getrennt
		// Background Priority damit CPU-intensive Arbeit nicht UI unterbricht
		HandlerThread thread = new HandlerThread("ServiceStartArguments",
			Process.THREAD_PRIORITY_BACKGROUND);
		thread.start();

		// Looper des HandlerThreads holen und für Handler nutzen
		mServiceLooper = thread.getLooper();
		mServiceHandler = new ServiceHandler(mServiceLooper);
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		Toast.makeText(this, "service starting", Toast.LENGTH_SHORT).show();

		// Sende für jeden Start Request eine Message um neuen Job zu starten
		// Start ID übergeben, um zu wissen, welcher Request gestoppt wird bei beenden des Jobs
		Message msg = mServiceHandler.obtainMessage();
		msg.arg1 = startId;
		mServiceHandler.sendMessage(msg);

		// Wird der Service gekillt, soll er neustarten
		return START_STICKY;
	}

	@Override
	public IBinder onBind(Intent intent) {
		// Binding wird nicht genutzt, also null zurückgeben
		return null;
	}

	@Override
	public void onDestroy() {
		Toast.makeText(this, "service done", Toast.LENGTH_SHORT).show();
	}
}