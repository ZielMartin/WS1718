public class LocalService extends Service {
    // Binder, der an Clients übergeben wird
    private final IBinder mBinder = new LocalBinder();
    // Zufallszahlen Generator
    private final Random mGenerator = new Random();

    /**
     * Klasse, die den Binder für Clients zur Verfügung stellt
     */
    public class LocalBinder extends Binder {
        LocalService getService() {
			// Rückgabe einer Instanz von LocalService damit Clients public Methoden aufrufen können
            return LocalService.this;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    /** Methode die von Clients genutzt wird */
    public int getRandomNumber() {
      return mGenerator.nextInt(100);
    }
}