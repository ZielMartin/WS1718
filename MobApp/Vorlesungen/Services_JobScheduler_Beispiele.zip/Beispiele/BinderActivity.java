public class BindingActivity extends Activity {
    LocalService mService;
    boolean mBound = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }

    @Override
    protected void onStart() {
        super.onStart();
        // Verbinden mit LocalService
        Intent intent = new Intent(this, LocalService.class);
		
		// BIND_AUTO_CREATE weil Service nur läuft solange Client verbunden ist
        bindService(intent, mConnection, Context.BIND_AUTO_CREATE);
    }

    @Override
    protected void onStop() {
        super.onStop();
        unbindService(mConnection);
        mBound = false;
    }

    /** Aufgerufen, wenn ein Button gedrückt wird */
    public void onButtonClick(View v) {
        if (mBound) {
            // Methode von LocalService aufrufen
            int num = mService.getRandomNumber();
            Toast.makeText(this, "number: " + num, Toast.LENGTH_SHORT).show();
        }
    }
	
	/** Callbacks für Servicebinding definieren, die an bindService() übergeben werden */
    private ServiceConnection mConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName className,
                IBinder service) {
			// Verbindung zu LocalService wurde hergestellt, IBinder casten 
			// und Instanz von LocalService holen
            LocalBinder binder = (LocalBinder) service;
            mService = binder.getService();
            mBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName arg0) {
            mBound = false;
        }
    };
}