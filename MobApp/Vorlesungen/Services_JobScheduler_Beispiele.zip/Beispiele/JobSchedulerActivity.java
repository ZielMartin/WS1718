public class JobSchedulerActivity extends Activity{
	
	private static final int JOB_ID = 1234;
	
	@Override
	protected void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		JobScheduler jobScheduler = getSystemService(JobScheduler.class);
		//ausstehende Jobs anzeigen
		List<JobInfo> jobs = jobScheduler.getAllPendingJobs();
		StringBuilder sb = new StringBuilder();
		for(JobInfo info : jobs){
			sb.append(info.toString());
			sb.append("\n");
		}
		if(sb.length() == 0){
			sb.append(getString(R.string.no_jobs));
		}
		//Die Klasse des Jobs
		ComponentName serviceEnpoint = new ComponentName(this, JobSchedulerService.class);
		JobInfo jobInfo = new JobInfo.Builder(Job_ID, serviceEndpoint)
				//alle 10 Sekunden wiederholen
				.setPeriodic(10000)
				//nur wenn das Ladekabel angeschlossen ist
				.setRequiredCharging(true);
				.build();
		//die Ausführung planen
		jobScheduler.schedule(jobInfo);
	}
}