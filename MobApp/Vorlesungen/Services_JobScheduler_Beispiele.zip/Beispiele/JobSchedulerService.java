public class JobSchedulerService extends JobService{
	private static final String TAG = JobSchedulerService.class.getSimpleName();
	
	@Override
	public boolean onStartJob(final JobParameters params){
		Log.d(TAG, "onStartJob()");
		Thread t = new Thread(new Runnable(){
			@Override
			public void run(){
				Log.d(TAG, "Job in Aktion");
				jobFinished(params, false);
			}
		});
		t.start();
		return true;
	}
	
	@Override
	public boolean onStopJob(JobParameters params){
		Log.d(TAG, "onStopJob()");
		return false;
	}
}