public class MessengerService extends Service {
	/** Command to the service to display a message */
    static final int MSG_SAY_HELLO = 1;

    /**
     * Schritt 1: Handler implementieren
     */
    class IncomingHandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MSG_SAY_HELLO:
                    Toast.makeText(getApplicationContext(), "hello!", Toast.LENGTH_SHORT).show();
                    break;
                default:
                    super.handleMessage(msg);
            }
        }
    }

    /**
     * Schritt 2: Handler nutzen um Messenger zu erstellen
     */
    final Messenger mMessenger = new Messenger(new IncomingHandler());

    /**
     * Schritt 3: Mithilfe des Messengers einen IBinder erstellen
	 * und diesen in onBind() zurückgeben
     */
    @Override
    public IBinder onBind(Intent intent) {
        Toast.makeText(getApplicationContext(), "binding", Toast.LENGTH_SHORT).show();
        return mMessenger.getBinder();
    }
}