public class ActivityMessenger extends Activity {
    /** Messenger um mit Service zu kommunizieren */
    Messenger mService = null;

    /** Wert um anzugeben ob wir mit einem Service verbunden sind */
    boolean mBound;

    /**
	 * Klasse um mit dem Interface des Service zu interagieren
     */
    private ServiceConnection mConnection = new ServiceConnection() {
        public void onServiceConnected(ComponentName className, IBinder service) {
			// Wird aufgerufen, wenn die Verbindung zum Service hergestellt wurde
			// Liefert das Objekt um mit dem Service zu interagieren
			// Schritt 4: Client nutzt IBinder um Messenger zu instanziieren
            mService = new Messenger(service);
            mBound = true;
        }

        public void onServiceDisconnected(ComponentName className) {
            // Wird aufgerufen, wenn die Verbindung zum Service unterbrochen wird
            mService = null;
            mBound = false;
        }
    };

    public void sayHello(View v) {
        if (!mBound) return;
		// Erstellen und Senden einer Message zum Service
        Message msg = Message.obtain(null, MessengerService.MSG_SAY_HELLO, 0, 0);
        try {
            mService.send(msg);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }

    @Override
    protected void onStart() {
        super.onStart();
        // Binden an Service
        bindService(new Intent(this, MessengerService.class), mConnection,
            Context.BIND_AUTO_CREATE);
    }

    @Override
    protected void onStop() {
        super.onStop();
        // Verbindung zum Service schließen
        if (mBound) {
            unbindService(mConnection);
            mBound = false;
        }
    }
}