public class HelloIntentService extends IntentService {

  /**
   * Konstruktor ruft Konstruktor der Oberklasse mit Namen des Threads auf
   */
  public HelloIntentService() {
      super("HelloIntentService");
  }

  /**
   * Diese Methode behandelt den übergebenen Intent
   * Wenn Methode fertig ist, stoppt der Service
   */
  @Override
  protected void onHandleIntent(Intent intent) {
      // Behandlung des Intents, fürs Beispiel einfach 5 Sekunden warten
      try {
          Thread.sleep(5000);
      } catch (InterruptedException e) {
          // Interrupt status wiederherstellen.
          Thread.currentThread().interrupt();
      }
  }
}